import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
emp = {
  'empid' : '10379',
  'empName' : 'Ragunath'
};


constructor() { }

empDetails() {
return this.emp;
}

}
