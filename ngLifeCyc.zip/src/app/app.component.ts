import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './employee.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.sass']
})
export class AppComponent implements OnInit {
  empd: any;
empdata: any;
greeter: any;
valueAChang: any;
  constructor(empDetail: EmployeeService) {
    console.log('constructor is method of class in typescript used in dependency injection');
    //  console.log(empDetail.empDetails());
    //  this.empdata = empDetail.empDetails();
    //  this.greeter = new emValu();
    //  console.log(this.greeter.testuser(this.empdata));
    this.valueAChang = 'onchange user';
   }
   ngOnInit(): void {
   // console.log('Oninit');
   // this.emData();
   }
    emData() {
      console.log(this.empd = this.empdata.empid);
    }
}

// tslint:disable-next-line:class-name
// class emValu {
//  testuser(data) {
//    return 'Ragunath ' + data.empid;
//  }
// }
