import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-detailsdata',
  templateUrl: './detailsdata.component.html',
  styleUrls: ['./detailsdata.component.scss']
})
export class DetailsdataComponent {

  @Input() onchangeVal;
  ngCon: boolean;
  constructor() {
    console.log('new - data is constructor' , this.onchangeVal);
    this.onchangeVal = 'data user';
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnChanges() {
     console.log('new - data is ngOnChanges' , this.onchangeVal = 'data user');
    // setTimeout(function() {
    //   console.log('new - data is ngOnChanges' , this.onchangeVal = 'ngOnChanges');
    // }, 2000);
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnInit() {
    this.ngCon = true;
     console.log('new - data is ngOnInit' , this.onchangeVal);
    // setTimeout(function() {
    //   console.log('new - data is ngOnInit' , this.onchangeVal = 'ngOnInit');
    // }, 2000);
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngDoCheck() {
    console.log('new - data is ngDoCheck' , this.onchangeVal = 'docheck');
    // setTimeout(function() {
    //   console.log('new - data is ngDoCheck' , this.onchangeVal = 'docheck')
    // }, 2000);
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngAfterContentInit() {
    console.log('new - data is ngAfterContentInit ---' , this.onchangeVal = 'ngAfterContentInit');
    //  setTimeout(function() {
    //   console.log('new - data is ngAfterContentInit --*' , this.onchangeVal = 'ngAfterContentInit');
    // }, 2000);
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngAfterContentChecked() {
    console.log('new - data is ngAfterContentChecked ---' , this.onchangeVal = 'ngAfterContentChecked');
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngAfterViewInit() {
   // console.log('new - data is ngAfterViewInit ---' , this.onchangeVal = 'ngAfterViewInit');
         setTimeout(function() {
      console.log('new - data is ngAfterViewInit --*' , this.onchangeVal = 'ngAfterViewInit');
    }, 2000);
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngAfterViewChecked() {
    // setTimeout(function() {
    //   console.log('new - data is ngAfterViewChecked --*' , this.onchangeVal = 'ngAfterViewChecked');
    // }, 2000);
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    console.log('ngOnDestroy');
  }
}
